# pptxgenjs Patterns for Report-to-PPTX

## Base Setup

```javascript
const pptxgen = require("pptxgenjs");
const pres = new pptxgen();
pres.layout = "LAYOUT_16x9"; // 10" x 5.625"
pres.author = "WorkBuddy";
pres.title = "Presentation Title";
```

## Color Constants

```javascript
const C = {
  primary: "1E3A8A",
  secondary: "3B82F6",
  accent: "06B6D4",
  light: "E0F2FE",
  darkText: "1E293B",
  muted: "64748B",
  bgLight: "F8FAFC",
  darkBg: "0F172A",
  white: "FFFFFF",
  coral: "F43F5E",
};
const FONT_CN = "Microsoft YaHei";
```

## Helpers

```javascript
function freshShadow() {
  return { type: "outer", color: "000000", blur: 6, offset: 2, angle: 135, opacity: 0.12 };
}

function addSlideTitle(slide, title, subtitle = null) {
  slide.addText(title, { x: 0.5, y: 0.45, w: 9, h: 0.55, fontSize: 28, fontFace: FONT_CN, bold: true, color: C.primary });
  if (subtitle) {
    slide.addText(subtitle, { x: 0.5, y: 1.0, w: 9, h: 0.35, fontSize: 14, fontFace: FONT_CN, color: C.muted });
  }
}

function addFooter(slide) {
  slide.addText("Source / Date", { x: 0.5, y: 5.25, w: 9, h: 0.25, fontSize: 9, fontFace: FONT_CN, color: C.muted });
}
```

## Chart Options

```javascript
function chartOptions(opts = {}) {
  return {
    x: 0.5, y: 1.5, w: 9, h: 3.6,
    chartColors: [C.secondary, C.accent, C.primary],
    chartArea: { fill: { color: C.white } },
    catAxisLabelColor: C.muted,
    valAxisLabelColor: C.muted,
    valGridLine: { color: "E2E8F0", size: 0.5 },
    catGridLine: { style: "none" },
    showLegend: false,
    showValue: true,
    dataLabelColor: C.darkText,
    dataLabelFontSize: 10,
    dataLabelPosition: "outEnd",
    barGapWidthPct: 35,
    ...opts,
  };
}

function hbarChart(data, labels, opts = {}) {
  return [[{ name: "数值", labels, values: data }], chartOptions({ barDir: "bar", ...opts })];
}

function vbarChart(data, labels, opts = {}) {
  return [[{ name: "数值", labels, values: data }], chartOptions({ barDir: "col", ...opts })];
}

// Usage
slide.addChart(pres.charts.BAR, ...hbarChart([52, 43, 36], ["A", "B", "C"], { x: 0.55, y: 1.5, w: 4.5, h: 3.2 }));
```

## Layout Cards

```javascript
slide.addShape(pres.shapes.RECTANGLE, { x: 0.6, y: 1.6, w: 2.8, h: 3.0, fill: { color: C.white }, line: { color: "E2E8F0", width: 1 }, shadow: freshShadow() });
slide.addText("Card Title", { x: 0.7, y: 1.75, w: 2.6, h: 0.35, fontSize: 15, fontFace: FONT_CN, bold: true, color: C.darkText });
slide.addText("Card body text", { x: 0.7, y: 2.15, w: 2.6, h: 2.2, fontSize: 11, fontFace: FONT_CN, color: C.muted });
```

## Section Divider

```javascript
let s = pres.addSlide();
s.background = { color: C.primary };
s.addText("01", { x: 0.7, y: 1.9, w: 8.6, h: 1.0, fontSize: 72, fontFace: FONT_CN, bold: true, color: C.white });
s.addText("Section Title", { x: 0.7, y: 2.9, w: 8.6, h: 0.8, fontSize: 40, fontFace: FONT_CN, bold: true, color: C.white });
```

## QA Commands

```bash
# Extract text
python -m markitdown output.pptx

# Check slide count
python - <<'PY'
from pptx import Presentation
prs = Presentation('output.pptx')
print(len(prs.slides))
PY
```
