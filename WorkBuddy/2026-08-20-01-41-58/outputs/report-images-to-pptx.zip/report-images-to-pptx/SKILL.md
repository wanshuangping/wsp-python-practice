---
name: report-images-to-pptx
description: Convert a series of report screenshots or slide images into a structured, visually designed PowerPoint presentation. Use when the user uploads multiple report/infographic images and asks to create a PPT, slide deck, or presentation based on them.
agent_created: true
---

# Report Images to PPTX

## Overview

This skill enables WorkBuddy to turn a sequence of report screenshots, infographic images, or existing slide images into a new PowerPoint (.pptx) file. It covers content extraction, structural planning, visual design, generation with pptxgenjs, and basic QA.

## When to Use

- User uploads multiple images/screenshots of a report and asks for a PPT.
- User references clipboard/local image paths of slides and requests a slide deck.
- The source images contain charts, tables, rankings, or explanatory text that need to be preserved in presentation form.

## Workflow

### 1. Read and Extract Content

- View every provided image using the Read tool (images render visually).
- Extract for each image: title, key arguments, data points, chart values, and any source notes.
- Build a structured outline grouped into logical chapters/sections.
- Note data accuracy; double-read blurry or dense charts when numbers matter.

### 2. Plan the Presentation

- Decide total slide count (usually 1 image → 1 slide, but consolidate related images when appropriate).
- Choose a color palette tied to the topic; default to a professional blue/teal for tech/business reports.
- Pick 2-3 recurring layouts: title slide, section divider, chart slide, comparison slide, card grid, conclusion.
- Define fonts that support Chinese and Latin characters (e.g., "Microsoft YaHei").

### 3. Set Up pptxgenjs

- Ensure a Node.js workspace exists with `pptxgenjs` installed.
- Prefer the managed Node runtime and isolated package workspace.
- Use absolute paths for output files under the project workspace.

### 4. Generate the PPT

- Create a Node.js script using pptxgenjs.
- Define reusable helpers: `addSlideTitle`, `addFooter`, `chartOptions`, `freshShadow`.
- Keep consistent margins (≥0.5" from slide edges) and avoid footer collisions.
- Use charts for data, tables for comparisons, and cards/grids for grouped concepts.
- Set `LAYOUT_16x9` and use hex colors without `#`.

### 5. Quality Check

- Run the script and verify the file is created.
- Use `python -m markitdown output.pptx` to extract text and confirm no placeholder content.
- Use `python-pptx` to verify slide count and basic structure.
- If LibreOffice is available, convert to PDF/images and visually inspect for overlaps; otherwise flag the limitation.

### 6. Deliver

- Present the .pptx file with `present_files`.
- Summarize slide count, structure, and any known caveats.

## Common Pitfalls

- `addChart` expects an **array of series objects** as the second argument, not a single object.
- Never use `#` in hex color strings.
- Do not reuse option objects across multiple pptxgenjs calls (objects are mutated in place).
- Leave at least 0.5" margin from slide edges and keep bottom elements clear of the footer at y≈5.25.
- Horizontal bar charts with many categories need adequate chart height and may require rotated labels.

## Resources

- `references/pptxgenjs-patterns.md` - Reusable code patterns for charts, tables, cards, and section dividers.
